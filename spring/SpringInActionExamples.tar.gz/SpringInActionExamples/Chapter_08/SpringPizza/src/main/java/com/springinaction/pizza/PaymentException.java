package com.springinaction.pizza;

@SuppressWarnings("serial")
public class PaymentException extends Exception {
  public PaymentException() {}
}
