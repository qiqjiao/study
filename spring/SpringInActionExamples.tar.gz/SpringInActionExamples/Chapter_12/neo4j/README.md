spring-data-neo4j-samples
=========================
The project is not intended to be built into a deployable JAR file,
but instead includes a test case that demonstrates Spring Data Mongo.
You may run this test case with 'mvn test' or import the project into
your IDE and run the test there.
